<style>
    .course-image {
        width: 400px !important;
        height: 220px !important;
    }
</style>

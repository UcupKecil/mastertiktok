<section class="hero-area">
    <div class="container">
        <div class="caption-content text-center">
            <h4>Start learning from home</h4>
            <h2>Connect With Our Expert And Start Learning Today</h2>
            <p>We are providing high-quality online courses to improve your skill. Our all instructors are highly
                experienced and experts.</p>
            <ul>
                <li><a href="#">Find courses</a></li>
                <li><a class="btn-bg" href="#">Start free trial</a></li>
            </ul>
        </div>
    </div>
</section>

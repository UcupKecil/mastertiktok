<!--proper js-->
<script src="{{ asset('assets/templates/omexo/assets/js/popper.min.js') }}"></script>
<!--bootstrap js-->
<script src="{{ asset('assets/templates/omexo/assets/js/bootstrap.min.js') }}"></script>
<!--mainmenu js-->
<script src="{{ asset('assets/templates/omexo/assets/js/meanmenu.min.js') }}"></script>
<!--counterup js-->
<script src="{{ asset('assets/templates/omexo/assets/js/counterup.min.js') }}"></script>
<!--waypoints js-->
<script src="{{ asset('assets/templates/omexo/assets/js/waypoints.js') }}"></script>
<!--magnic popup js-->
<script src="{{ asset('assets/templates/omexo/assets/js/magnific-popup.min.js') }}"></script>
<!--owl carousel js-->
<script src="{{ asset('assets/templates/omexo/assets/js/owl.carousel.min.js') }}"></script>
<!--syotimer js-->
<script src="{{ asset('assets/templates/omexo/assets/js/syotimer.min.js') }}"></script>
<!--main js-->
<script src="{{ asset('assets/templates/omexo/assets/js/custom.js') }}"></script>
@stack('script')

<button type="button" class="btn btn-sm btn-primary my-3" onClick="create()">
    <span class="btn-label">
        @include('components.icons.add')
    </span>
    Tambah Data
</button>

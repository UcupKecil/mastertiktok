<a href="{{ $formUrl }}" class="btn btn-sm btn-primary my-3">
    <span class="btn-label">
        @include('components.icons.add')
    </span>
    Tambah Data
</a>

<a href="{{ $path }}" data-lightbox="image-{{ $id }}" data-title="{{ $name }}">
    <img src="{{ $path }}" alt="{{ $name }}" class="img img-thumbnail" width="100px" height="100px">
</a>

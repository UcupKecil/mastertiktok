<?php

includeRouteFiles(__DIR__ . '/web/');
